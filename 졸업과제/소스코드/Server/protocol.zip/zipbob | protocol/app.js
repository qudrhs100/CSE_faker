
/*eslint-env node, mongodb*/
/**
 * Module dependencies.
 */
var express = require('express'); 
var http = require('http');
var path = require('path');
var fs = require('fs');
var app = express();

var cheerio = require('cheerio');
var request = require('request');

var fileToUpload;

var monk = require('monk');
//var db = monk('mongodb://protocol:123456@aws-us-east-1-portal.20.dblayer.com:11142/lin'); 
var db = monk('mongodb://protocol:123456@aws-us-east-1-portal.20.dblayer.com:11315/lin');

var bodyParser = require('body-parser');
var methodOverride = require('method-override');
var logger = require('morgan');
var errorHandler = require('errorhandler');
var multipart = require('connect-multiparty');
var multipartMiddleware = multipart();

// all environments
app.set('port', process.env.PORT || 3000);
app.set('views', path.join(__dirname,'/views'));
app.set('view engine', 'ejs');
app.engine('html', require('ejs').renderFile);
app.use(logger('dev'));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(methodOverride());
app.use(express.static(path.join(__dirname, 'public')));
app.use('/style', express.static(path.join(__dirname, '/views/style')));


var routes = require('./routes/router');
var user = require('./routes/user');

var appKey = 'e2fa26a4-10c2-3026-a5ea-09fca11659c7';
var city = '%EB%B6%80%EC%82%B0';
var county = '%EA%B8%88%EC%A0%95%EA%B5%AC';
var vilage = '%EC%9E%A5%EC%A0%84%EB%8F%99';
var weatherJSON;
var day = new Date().getDay(); //0이 일요일

var table = [];
var temptable =[];
var count = 0;
var url = 'http://apis.skplanetx.com/weather/current/hourly?appKey=' + appKey + '&format=json&version=1'
		+ '&city=' + city + '&county=' + county + '&village=' + vilage;
request(url, function(error, response, html) {
	if (error) {throw error;}
	weatherJSON = JSON.parse(html);
	//console.log(weatherJSON.weather);
});


setInterval(function(){
for (var i = 0 ; i < 6 ; i++) {
		(function(i) {
			var url2 = 'http://pusan.ac.kr/uPNU_homepage/kr/pages/1001060903.asp?sikdan_dt=' + i.toString();
			request(url2, function(error, response, html) {
				if(error) {throw error;}
				var $ = cheerio.load(html);

			function maketable(callback) {
				$('.table_rst.tb_cnt').find('tbody').find('td').each(function() {
					 temptable = temptable.concat($(this).text());
					//temptable = temptable.splice(0, 0, $(this).text());
				});
				//console.log("length "+temptable.length);
				callback();
			}
			function printtable() {
				for (var j =  0 ; j <temptable.length ; j++) {
					//console.log("j = "+j+"temptable[j] "+temptable[j]);
					if (temptable[j].indexOf("금정회관 1층") != -1) {		
						console.log("temp= "+temptable[j+2]);
						console.log("number check "+(0+i*3));
						table[0 + i*3] = temptable[j+2];
						table[1 + i*3] = temptable[j+4];
						table[2 + i*3] = temptable[j+6];
						//console.log(table[0]);
						break;
					}
				}
			}
			maketable(printtable);
			temptable =[];
			});
		})(i);
	}	
},86400000);

for (var i = 0 ; i < 6 ; i++) {
		(function(i) {
			var url2 = 'http://pusan.ac.kr/uPNU_homepage/kr/pages/1001060903.asp?sikdan_dt=' + i.toString();
			request(url2, function(error, response, html) {
				if(error) {throw error;}
				var $ = cheerio.load(html);

			function maketable(callback) {
				$('.table_rst.tb_cnt').find('tbody').find('td').each(function() {
					 temptable = temptable.concat($(this).text());
					//temptable = temptable.splice(0, 0, $(this).text());
				});
				//console.log("length "+temptable.length);
				callback();
			}
			function printtable() {
				for (var j =  0 ; j <temptable.length ; j++) {
					//console.log("j = "+j+"temptable[j] "+temptable[j]);
					if (temptable[j].indexOf("금정회관 1층") != -1) {		
						console.log("temp= "+temptable[j+2]);
						console.log("number check "+(0+i*3));
						table[0 + i*3] = temptable[j+2];
						table[1 + i*3] = temptable[j+4];
						table[2 + i*3] = temptable[j+6];
						//console.log(table[0]);
						break;
					}
				}
			}
			maketable(printtable);
			temptable =[];
			});
		})(i);
	}	




	//console.log("for loop test = "+table[0]);
app.use(function(req,res,next){
	req.db=db;
	req.weatherJSON=weatherJSON;
	req.table=table;
	next();
});

app.use('/',routes);
app.use('/user',user.list);

// development only
if ('development' == app.get('env')) {
	app.use(errorHandler());
}
http.createServer(app).listen(app.get('port'), '0.0.0.0', function() {
	console.log('Express server listening on port ' + app.get('port'));
});


