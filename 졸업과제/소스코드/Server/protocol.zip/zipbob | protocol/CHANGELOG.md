## Feb 2, 2016
- Change engine to Node v4.2
- Update dependency versions to latest minor

## Nov 16, 2015
- Added changelog
