/*eslint-env node */

var express = require('express');
var fs = require('fs');
var router = express.Router();

router.get('/',function(req,res){
	res.render('index');
});


router.get('/map',function(req,res){
	res.render('map');
});


router.get('/test',function(req,res){
	var hjy = req.weatherJSON;
	//hjy = hjy.hourly;
	//console.log("testing = "+hjy);
	//res.render('test',hjy)
	var db = req.db;
	var table = req.table;
	console.log("table test = " + table[0]);
	var collection = db.get('2016/6');
	var collection2 = db.get('2016/7');
	var temp;
	collection.find({},{},function(e,docs){
		temp = docs;
	});
	collection2.find({},{},function(e,docs){
		res.render('test',{"col1":temp,"col2":docs,"col3":table});	
	});
});

router.get('/hjy',function(req,res){
	res.render('hjy');
});

router.get('/now',function(req,res){
  var year = new Date().getYear()+1900;
  var month = new Date().getMonth()+1;
  var date = new Date().getDate();
  var day = new Date().getDay();//숫자 0 이 일요일 
  var hour = new Date().getHours()+9;
  var db = req.db;
  var collection = db.get(year+"/"+month);
  collection.find({}, {}, function(e,docs) {
    res.render('now' , {"list" : docs,"year":year,"month":month,"date2":date,"day2":day,"hour2":hour});
  });
});

router.get('/bob',function(req,res){
	var table =req.table;
	var day = new Date().getDay();//숫자 0 이 일요일
	res.render('bob',{"col3":table,"dat":day});
});

router.get('/hour',function(req,res){
	var year = new Date().getYear()+1900;
	var beforemonth = new Date().getMonth();
	var month = new Date().getMonth()+1;
	var date = new Date().getDate();
	var db = req.db;
	var collection = db.get(year+"/"+beforemonth);
  	var collection2 = db.get(year+"/"+month);
  	var tmp;
 
  collection.find({}, {}, function(e,docs) {
    tmp =  docs;
    collection2.find({}, {}, function(e,docs) {
      res.render('hour' , {"month" : beforemonth ,"datedate" : date ,"month2" : month , "plist" : tmp , "plist2" : docs});
    });
  });
});

router.get('/day',function(req,res){
	var year = new Date().getYear()+1900;
	var month = new Date().getMonth()+1;
	var date = new Date().getDay();
	var hour = new Date().getHours()+9;
	var db = req.db;
	var collection = db.get(year+"/"+month);
 	 collection.find({}, {}, function(e,docs) {
 	 res.render('day' , {"month" : month ,"datedate" : date, "hours":hour,"templist" : docs});
	});
});


router.get('/list',function(req,res){
	var db = req.db;
	var collection = db.get('young');
	var date =
	collection.find({},{},function(e,docs){
		res.render('test',{users:docs});	
	});
});

router.get('/insert', function(req, res) {
	var year = new Date().getYear()+1900;
	var month = new Date().getMonth()-1;
	var date = new Date().getDate();
	var day = new Date().getDay();//숫자 0 이 일요일 
	var hour = new Date().getHours()+9;
	var minute = new Date().getMinutes();
	var second = new Date().getSeconds();
	var db = req.db;
	var collection = db.get(year+"/"+month);
	
	collection.insert({
		"date":date,
		"day":day,
		"hour":hour,
		"camera_index":1,
		"IN":minute+30,
		"OUT":minute
	});
	  res.status(200).send("Inserted");
});

router.post('/receive', function(req,res){
		var chunk='';
		console.log('receive test');
		req.accepts('application/json');
		chunk = req.body;
		var year = new Date().getYear()+1900;
		var month = new Date().getMonth()+1;
		var date = new Date().getDate();
		var day = new Date().getDay();//숫자 0 이 일요일 
		var hour = new Date().getHours()+9;
		hour = hour%24;
		var minute = new Date().getMinutes();
		var second = new Date().getSeconds();
		
		var db = req.db;
		var collection = db.get(year+"/"+month);
		
		req.on('data',function(data){
			console.log("data: "+data);
			chunk = JSON.parse(data);
			console.log("chunk: "+chunk.name);
			/*
			collection.insert({
			"date":date,
			"day":day,
			"hour":hour,
			"camera_index" : chunk.name,
			"IN" : chunk.age,
			"OUT" : 0
			});
			*/
			collection.update({"date":date , "day":day , "hour":hour , "camera_index": chunk.name} , {$set : {"IN" : chunk.inCount , "OUT": chunk.outCount }} , {"upsert": true});
			
			//collection.update({"date":date+1 , "day":day+1 , "hour":hour+1} , {$set : {"IN" : 11111 , "OUT": 11111}} , {"upsert": true});
			
		});
		
		req.on('end',function(){
			console.log("end: name: "+chunk.name);
		});
		
		//console.log("name : "+chunk.name);
		res.write("OK");
		res.end();
});

module.exports = router;
