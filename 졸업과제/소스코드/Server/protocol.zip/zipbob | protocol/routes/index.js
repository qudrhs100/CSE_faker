
/*
 * GET home page.
 */

/*eslint-env node */
exports.index = function(req, res){
  res.render('index.html', { title: 'Hwang' });
};